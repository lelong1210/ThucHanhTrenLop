<?php
    require_once "./mvc/bridge.php";
    new app();
?>