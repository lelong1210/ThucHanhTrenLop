<?php
    require_once "smarthome.php";

    echo "IPHONE====<br>";
    $iphone = new iphone();
    echo "SAMSUNG====<br>";
    $samsung = new samsung();
?>