<?php
    require_once "fruit.php";
    $test = new fruitChild();
    $test->testFruit("grapefruit","blue");
?>  