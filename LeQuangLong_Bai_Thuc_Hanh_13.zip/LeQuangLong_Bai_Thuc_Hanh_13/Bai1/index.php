<?php
    require_once "bai1.php";
    new bai1();
?>