<?php
    require_once "bai2.php";
    new bai2();
?>