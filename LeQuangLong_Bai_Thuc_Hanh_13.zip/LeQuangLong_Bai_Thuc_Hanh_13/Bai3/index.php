<?php
    require_once "bai3.php";
    new bai3();
?>